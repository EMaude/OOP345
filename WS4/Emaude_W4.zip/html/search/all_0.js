var searchData=
[
  ['display',['display',['../classw4_1_1Message.html#a50f73e62517b4fd91aee237b2a1219a1',1,'w4::Message::display()'],['../classw4_1_1Notifications.html#acc3ba79fc7ba0832a5800ba3c45fa85f',1,'w4::Notifications::display()']]]
];
