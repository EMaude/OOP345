var searchData=
[
  ['_7enotifications',['~Notifications',['../classw4_1_1Notifications.html#a6c75650682b33d66fceb051c8dfd03be',1,'w4::Notifications']]]
];
