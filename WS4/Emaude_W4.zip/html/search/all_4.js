var searchData=
[
  ['operator_2b_3d',['operator+=',['../classw4_1_1Notifications.html#af9122e1c8f208339bf2d8e688cafbfdb',1,'w4::Notifications']]],
  ['operator_3d',['operator=',['../classw4_1_1Message.html#add820c5d577883b1dac14fcb6f314a8c',1,'w4::Message::operator=()'],['../classw4_1_1Notifications.html#a02075659039488d971d92dc74ede102c',1,'w4::Notifications::operator=(const Notifications &amp;in)'],['../classw4_1_1Notifications.html#a849e1d329f366d7c7d08d4b101f11227',1,'w4::Notifications::operator=(Notifications &amp;&amp;in)']]]
];
