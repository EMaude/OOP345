var searchData=
[
  ['notifications',['Notifications',['../classw4_1_1Notifications.html',1,'w4::Notifications'],['../classw4_1_1Notifications.html#ae6e788da6f7db8a0c0b40707bbfc4872',1,'w4::Notifications::Notifications()'],['../classw4_1_1Notifications.html#a273c7ea71457fddec66c6f44e32306c6',1,'w4::Notifications::Notifications(const Notifications &amp;in)'],['../classw4_1_1Notifications.html#af64d7a31e92189f43953bc98c36ef234',1,'w4::Notifications::Notifications(Notifications &amp;&amp;)']]]
];
