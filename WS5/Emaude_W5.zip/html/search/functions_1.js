var searchData=
[
  ['grades',['Grades',['../classGrades.html#af90498072e837401f75360ad5ab75d35',1,'Grades::Grades(const char *filename)'],['../classGrades.html#a69ad59efbd39390f70b95a114782ce9e',1,'Grades::Grades(Grades &amp;)=delete'],['../classGrades.html#a3b7bfcbef2ea339755ed8ba0b0ac4d88',1,'Grades::Grades(Grades &amp;&amp;)=delete']]]
];
