var searchData=
[
  ['_7etext',['~Text',['../classw2_1_1Text.html#a803254d0b1ee4f61831f575a4f8e76f9',1,'w2::Text']]]
];
