var searchData=
[
  ['size',['size',['../classw2_1_1Text.html#ac71ea4c77b1de8e0d4849556b08c0f50',1,'w2::Text']]]
];
