var indexSectionsWithContent =
{
  0: "ost~",
  1: "t",
  2: "ost~"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

