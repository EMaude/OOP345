var searchData=
[
  ['text',['Text',['../classw2_1_1Text.html',1,'w2']]]
];
