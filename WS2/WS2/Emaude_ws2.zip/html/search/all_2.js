var searchData=
[
  ['text',['Text',['../classw2_1_1Text.html',1,'w2::Text'],['../classw2_1_1Text.html#afd307eb0367f8d0ee60caab44065c211',1,'w2::Text::Text(const std::string &amp;str)'],['../classw2_1_1Text.html#a2230a4ab15171e50cc4482310e8c8ec0',1,'w2::Text::Text(const Text &amp;src)'],['../classw2_1_1Text.html#a66ea2a1f10768fb1d3cedab85a208bec',1,'w2::Text::Text(Text &amp;&amp;src)']]]
];
