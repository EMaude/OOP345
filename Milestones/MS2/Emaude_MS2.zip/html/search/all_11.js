var searchData=
[
  ['validate',['validate',['../class_task.html#a974eb3143ac070fd67495f3c4a108a96',1,'Task']]]
];
