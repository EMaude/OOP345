var searchData=
[
  ['quality',['Quality',['../class_task.html#a6b8b1fc5858cbd77055e79d6381282fb',1,'Task']]]
];
