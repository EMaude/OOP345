var searchData=
[
  ['display',['display',['../class_customer_item.html#a2aaa8551a3662bb4b2953704580fc408',1,'CustomerItem::display()'],['../class_customer_order.html#a44b8223600dd858b4d4edcbe3704a5a0',1,'CustomerOrder::display()'],['../class_item.html#a9433e55e0165564bbbdb77bd01853728',1,'Item::display()'],['../class_task.html#aff00aecd7c14bd02434b76ad10a656a2',1,'Task::display()']]]
];
