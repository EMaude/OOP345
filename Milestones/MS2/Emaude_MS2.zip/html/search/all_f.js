var searchData=
[
  ['task',['Task',['../class_task.html',1,'Task'],['../class_task.html#ace3ff25451f6d46f6cc0f2d7ed4b16ef',1,'Task::Task()']]],
  ['task_2ecpp',['Task.cpp',['../_task_8cpp.html',1,'']]],
  ['task_2eh',['Task.h',['../_task_8h.html',1,'']]],
  ['trim',['trim',['../class_utilities.html#ac71774c0324d441f542665f8f372a113',1,'Utilities']]]
];
