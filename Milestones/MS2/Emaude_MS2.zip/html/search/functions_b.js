var searchData=
[
  ['remove',['remove',['../class_customer_order.html#a8059d5a73bfa388f86671d45835468d6',1,'CustomerOrder']]],
  ['rtrim',['rtrim',['../class_utilities.html#afffccc73f8e56740fdf789904bf268ee',1,'Utilities']]]
];
