var searchData=
[
  ['empty',['empty',['../class_customer_order.html#a8cfde59bf7a044e21508f5b595e3873c',1,'CustomerOrder::empty()'],['../class_item.html#a8a1745ce42e5695d5c63c62bd5be7d8e',1,'Item::empty()']]]
];
