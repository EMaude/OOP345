var searchData=
[
  ['display',['display',['../class_task.html#aff00aecd7c14bd02434b76ad10a656a2',1,'Task']]]
];
