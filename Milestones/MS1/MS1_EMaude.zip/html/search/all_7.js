var searchData=
[
  ['passed',['passed',['../class_task.html#a6b8b1fc5858cbd77055e79d6381282fbafc26836e15aeaddaab5eaca6d03dadba',1,'Task']]]
];
