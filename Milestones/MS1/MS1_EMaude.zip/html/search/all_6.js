var searchData=
[
  ['operator_3d_3d',['operator==',['../_task_8cpp.html#a596f914d9d7f0c3021276ccf82f99ffa',1,'operator==(const Task &amp;a, const Task &amp;b):&#160;Task.cpp'],['../_task_8h.html#a906f541fe7a4bc04232bf37358cc7fa7',1,'operator==(const Task &amp;, const Task &amp;):&#160;Task.cpp']]]
];
