var searchData=
[
  ['validate',['validate',['../class_order_manager.html#a5469cae831246813134630f8bd85db79',1,'OrderManager::validate()'],['../class_task.html#a974eb3143ac070fd67495f3c4a108a96',1,'Task::validate()'],['../class_task_manager.html#a2ae3c30ca4e030440b64c383cbda8a73',1,'TaskManager::validate(std::ostream &amp;)'],['../class_task_manager.html#a59aea57b2ad273d6d95797f93d737fa0',1,'TaskManager::validate(const ItemManager &amp;, std::ostream &amp;)']]]
];
