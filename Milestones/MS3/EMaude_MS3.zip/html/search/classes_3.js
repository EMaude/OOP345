var searchData=
[
  ['task',['Task',['../class_task.html',1,'']]],
  ['taskmanager',['TaskManager',['../class_task_manager.html',1,'']]]
];
