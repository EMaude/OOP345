var searchData=
[
  ['redirect',['redirect',['../class_task.html#a6b8b1fc5858cbd77055e79d6381282fba9a7ec146540b101a16e2da2bd61e5b59',1,'Task']]]
];
