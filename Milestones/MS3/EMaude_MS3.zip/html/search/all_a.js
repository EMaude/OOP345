var searchData=
[
  ['operator_2b_2b',['operator++',['../class_item.html#a818f9273ed8889c8b27cb97d2c292e77',1,'Item']]],
  ['operator_3d',['operator=',['../class_customer_order.html#ae43fcf650924cf82800c6dfe9a20afca',1,'CustomerOrder::operator=(const CustomerOrder &amp;)=delete'],['../class_customer_order.html#ae2af41f59a0b0856fae309779f915390',1,'CustomerOrder::operator=(CustomerOrder &amp;&amp;) NOEXCEPT']]],
  ['operator_3d_3d',['operator==',['../_task_8cpp.html#a596f914d9d7f0c3021276ccf82f99ffa',1,'operator==(const Task &amp;a, const Task &amp;b):&#160;Task.cpp'],['../_task_8h.html#a906f541fe7a4bc04232bf37358cc7fa7',1,'operator==(const Task &amp;, const Task &amp;):&#160;Task.cpp']]],
  ['operator_5b_5d',['operator[]',['../class_customer_order.html#a8ff1239910926e660ce7692807a7847d',1,'CustomerOrder']]],
  ['ordermanager',['OrderManager',['../class_order_manager.html',1,'']]],
  ['ordermanager_2ecpp',['OrderManager.cpp',['../_order_manager_8cpp.html',1,'']]],
  ['ordermanager_2eh',['OrderManager.h',['../_order_manager_8h.html',1,'']]]
];
