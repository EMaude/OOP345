var searchData=
[
  ['asksfor',['asksFor',['../class_customer_item.html#a6275dac4b75e3cd8e56f504140cd135d',1,'CustomerItem']]]
];
